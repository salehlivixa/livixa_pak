<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'نسخة احتياطية / استعادة';

// Text
$_['text_success']     = 'تم استيراد قاعدة البيانات بنجاح !';

// Entry
$_['entry_progress']   = 'حالة التقدم';
$_['entry_export']     = 'تصدير';

// Tab
$_['tab_backup']       = 'نسخة احتياطية';
$_['tab_restore']      = 'استعادة';

// Error
$_['error_permission'] = 'تحذير : أنت لا تمتلك صلاحيات التعديل !';
$_['error_export']     = 'تحذير : يجب اختيار جدول واحد على الأقل !';
$_['error_file']       = 'تعذر العثور على الملف !';
