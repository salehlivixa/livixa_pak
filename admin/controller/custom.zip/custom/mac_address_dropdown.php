<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    /* Attempt MySQL server connection. Assuming you are running MySQL
    server with default setting (user 'root' with no password) */
    $link = mysqli_connect("localhost", "root", "", "opencart_db");

    // Check connection
    if ($link === false) {
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }
    // Escape user inputs for security
    $order_id = $_POST['order_id'];
    $order_product_id = $_POST['order_product_id'];
    $mac_addresses = $_POST['mac_addresses'];
    $product_quantity = $_POST['product_quantity'];
    $saved = [];
    $failed = [];
    $failed_mac = '';
    $saved_mac = '';

    foreach ($mac_addresses as $key => $mac_address) {
        // attempt insert query execution
        $sql = "INSERT INTO order_mac_addresses (order_id, order_product_id, mac_address,product_quantity) VALUES ('$order_id', '$order_product_id', '$mac_address','$product_quantity')";
        if (mysqli_query($link, $sql)) {
            $saved[] = $mac_address . " added successfully <br>    ";
            $saved_mac = $saved_mac . ',' . $mac_address;

        } else {
            $failed[] = $mac_address . ' already exists in database <br>';
            $failed_mac = $failed_mac . ',' . $mac_address;
        }
    }

    $response = "<b> Success:</b>" . (($saved_mac != '') ? $saved_mac : ' No records Saved <br>') . "<b>Already Exists:</b>" . (($failed_mac != '') ? $failed_mac : ' No Records Failed');
    if ($saved_mac != null) {
        $get_mac = "Select * from order_mac_addresses where order_product_id=" . $order_product_id;
        $get_mac = $link->query($get_mac);
        $get_macx = [];
        foreach ($get_mac as $mac) {
            $get_macx[] = $mac['mac_address'];
        }
        $mac_addressx = implode(',', (array)$get_macx);
        $sql_update = "UPDATE oc_order_product SET mac_address='" . $mac_addressx . "' WHERE order_product_id = " . $order_product_id;
        mysqli_query($link, $sql_update);
    }
    mysqli_close($link);
    echo $response;
}
?>