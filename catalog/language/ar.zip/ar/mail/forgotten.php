<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_subject']  = '%s - طلب إعادة تعيين كلمة المرور';
$_['text_greeting'] = 'كلمة المرور الجديدة التي تم طلبها %s.';
$_['text_change']   = 'لإعادة تعيين كلمة المرور الرجاء النقر على الرابط التالي:';
$_['text_ip']       = 'رقم الاي بي الخاص بهذا الطلب: ';
