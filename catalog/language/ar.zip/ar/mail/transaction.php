<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_subject']  = '%s - العمولة';
$_['text_received'] = 'تهانينا. تم احتساب عمولتك %s !';
$_['text_amount']   = 'لقد استملت مبلغ :';
$_['text_total']    = 'اجمالي قيمة مبالغ عمولاتك حالياً هو %s ';
