<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_title']       = 'تكلفة ثابتة';
$_['text_description'] = 'تكلفة ثابتة للشحن';
