<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_title']       = 'تسليم يد بيد';
$_['text_description'] = 'الاستلام من المتجر';