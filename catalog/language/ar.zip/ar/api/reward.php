<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_success']     = 'نجاح: تم قبول الخصم بواسطة نقاط المكافآت !';

// Error
$_['error_permission'] = 'تحذير: انت لا تمتلك صلاحيات الدخول الى واجهة برمجة - API!';
$_['error_reward']     = 'تحذير: الرجاء ادخال قيمة نقاط المكافآت المطلوب استخدامها !';
$_['error_points']     = 'تحذير: لايوجد لديك %s نقاط مكافآت !';
$_['error_maximum']    = 'تحذير: الحد الأقصى المسموح به لنقاط المكافآت هو %s !';