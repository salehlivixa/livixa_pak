<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_success']           = 'تم التعديل !';

// Error
$_['error_permission']       = 'تحذير: انت لا تمتلك صلاحيات الدخول الى واجهة API!';
$_['error_customer']         = 'تحذير: يجب ضبط تفاصيل العميل !';
$_['error_payment_address']  = 'تحذير: عنوان الفاتورة مطلوب !';
$_['error_payment_method']   = 'تحذير: طريقة الدفع مطلوبة !';
$_['error_no_payment']       = 'تحذير: خيارات الدفع غير مفعلة !';
$_['error_shipping_address'] = 'تحذير: عنوان الشحن مطلوب !';
$_['error_shipping_method']  = 'تحذير: طريقة الشحن مطلوبة !';
$_['error_no_shipping']      = 'تحذير: خيارات الشحن غير مفعلة !';
$_['error_stock']            = 'تحذير: المنتجات التي عليها علامة *** كميتها غير متوفرة !';
$_['error_minimum']          = 'تحذير: قيمة الحد الأدنى للطلب %s هي %s!';
$_['error_not_found']        = 'تحذير: لم يتم العثور على الطلب !';