<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_success']     = 'تم تغييرالعملة !';

// Error
$_['error_permission'] = 'تحذير: انت لا تمتلك صلاحيات الدخول الى واجهة برمجة - API!';
$_['error_currency']   = 'تحذير: كود العملة غير صالح !';